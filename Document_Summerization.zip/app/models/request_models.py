from pydantic import BaseModel, HttpUrl # type: ignore

class URLRequest(BaseModel):
    url: HttpUrl
