import requests
from transformers import pipeline

t5_model = pipeline("summarization", model="t5-base")

async def summarize_content(url: str) -> str:
    with requests.get(url, stream=True) as response:
        response.raise_for_status()
        content = ''
        for chunk in response.iter_content(chunk_size=1024):
            content += chunk.decode('utf-8')
            if len(content) > 2000:
                content = content[:2000]
                break

    summary = t5_model(content, max_length=100, min_length=30, do_sample=False)[0]['summary_text']
    return summary
