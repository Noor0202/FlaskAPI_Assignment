import uuid

summ_list = {}

def save_summary(summary):
    summary_id = str(uuid.uuid4())
    summ_list[summary_id] = summary
    return summary_id

def get_summary_by_id(id):
    return summ_list.get(id)
