from fastapi import APIRouter, HTTPException # type: ignore
from app.models.request_models import URLRequest
from app.services.summarization_service import summarize_content
from app.storage.summary_storage import get_summary_by_id, save_summary

router = APIRouter()

@router.post("/summarize")
async def summarize_large_document(request: URLRequest):
    try:
        content = await summarize_content(request.url)
        summary_id = save_summary(content)
        return {"id": summary_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Error - " + str(e))

@router.get("/summary/{id}")
async def get_summary(id: str):
    summary = get_summary_by_id(id)
    if summary:
        return {"summary": summary}
    else:
        raise HTTPException(status_code=404, detail="Not found")
