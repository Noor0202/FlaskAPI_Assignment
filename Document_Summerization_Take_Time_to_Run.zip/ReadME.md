## Document Summarization API

project is built using FastAPI. the API fetch content from a given URL and summarize it using pre-trained models, stored the summary in memory and return a ID.

## How to Use -

1. Clone the Repository:

   git clone link

2. Install all Dependencies:

   pip install -r requirements.txt

3. To Run API

   uvicorn app.main:app --reload

4. POST Summary using CURL Command:

   curl -X POST "http://127.0.0.1:8000/summarize" -H "Content-Type: application/json" -d '{"url": "http://example.com/document"}'

5. GET Summary using CURL Command

   curl -X GET "http://127.0.0.1:8000/summary/{id}"
