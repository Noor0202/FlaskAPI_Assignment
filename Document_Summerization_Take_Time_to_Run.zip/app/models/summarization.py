from transformers import pipeline, AutoModelForSeq2SeqLM, AutoTokenizer
from datasets import load_dataset

class SummarizationModel:
    def __init__(self):
        self.datasets = {
            "cnn_dailymail": load_dataset("cnn_dailymail", "3.0.0"),
            "samsum": load_dataset("samsum", trust_remote_code=True),
        }

        self.models = {
            "t5-base": pipeline("summarization", model="t5-base"),
            "pegasus": pipeline("summarization", model="google/pegasus-cnn_dailymail"),
        }

        #using bart model
        self.tokenizer = AutoTokenizer.from_pretrained('facebook/bart-large-cnn')
        self.model = AutoModelForSeq2SeqLM.from_pretrained('facebook/bart-large-cnn')
        self.samsum = self.datasets["samsum"]

        def get_feature(batch):
            encodings = self.tokenizer(batch["dialogue"], text_target=batch["summary"], max_length=1024, truncation=True)
            return {'input_ids': encodings['input_ids'], 'attention_mask': encodings['attention_mask'], 'labels': encodings['labels']}

        self.samsum_pt = self.samsum.map(get_feature, batched=True, remove_columns=self.samsum["train"].column_names)
        self.columns = ['input_ids', 'labels', 'attention_mask']
        self.samsum_pt.set_format(type='torch', columns=self.columns)

        self.training_args = TrainingArguments(
            output_dir="bart_samsum",
            num_train_epochs=1,
            warmup_steps=500,
            per_device_train_batch_size=4,
            per_device_eval_batch_size=4,
            weight_decay=0.01,
            logging_steps=10,
            evaluation_strategy="steps",
            eval_steps=500,
            save_steps=1e6,
            gradient_accumulation_steps=16,
        )

        self.trainer = Trainer(
            model=self.model,
            args=self.training_args,
            tokenizer=self.tokenizer,
            data_collator=DataCollatorForSeq2Seq(self.tokenizer, model=self.model),
            train_dataset=self.samsum_pt["train"],
            eval_dataset=self.samsum_pt["validation"],
        )

        self.trainer.train()
        self.trainer.save_model("bart_samsum_model")

        self.models["bart-samsum"] = pipeline("summarization", model="bart_samsum_model")

    def summarize(self, text: str):
        summaries = {}
        for model_name, summarizer in self.models.items():
            summaries[model_name] = summarizer(text)[0]["summary_text"]
        return summaries
