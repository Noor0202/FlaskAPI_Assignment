import uuid

class SummaryStore:
    def __init__(self):
        self.store = {}

    def store_summary(self, summary):
        summary_id = str(uuid.uuid4())
        self.store[summary_id] = summary
        return summary_id

    def get_summary(self, summary_id):
        return self.store.get(summary_id)