from fastapi import APIRouter, HTTPException
from app.services.fetch_document import fetch_document_content
from app.storage.summary_store import SummaryStore
from app.utils.validators import validate_url
from app.models.summarization import SummarizationModel

router = APIRouter()

store = SummaryStore()
summarizer = SummarizationModel()

@router.post("/summarize")
def summarize_document(url: str):
    if not validate_url(url):
        raise HTTPException(status_code=400, detail="Invalid URL")

    content = fetch_document_content(url)
    if not content:
        raise HTTPException(status_code=404, detail="Unable to fetch Content")

    summary = summarizer.summarize(content)
    summary_id = store.store_summary(summary)

    return {"id": summary_id}

@router.get("/summary/{id}")
def get_summary(id: str):
    summary = store.get_summary(id)
    if not summary:
        raise HTTPException(status_code=404, detail="Summary not found")

    return {"summary": summary}
