import requests
from bs4 import BeautifulSoup

def fetch_document_content(url):
    try:
        response = requests.get(url)
        response.raise_for_status()

        content_type = response.headers['Content-Type']

        if 'text/html' in content_type:
            soup = BeautifulSoup(response.content, 'html.parser')
            return ("HTML Content", soup.get_text())

        elif 'text/plain' in content_type:
            return ("Text Content", response.text)

        elif 'application/json' in content_type:
            return ("JSON Content", response.json())

        else:
            return ("Unknown Type", "")
            
    except requests.exceptions.RequestException as e:
        return ("Error - ", str(e))