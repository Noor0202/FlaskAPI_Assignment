from fastapi import FastAPI
from app.routes.summary_routes import router as summary_router

app = FastAPI()

app.include_router(summary_router)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Document Summarization API"}